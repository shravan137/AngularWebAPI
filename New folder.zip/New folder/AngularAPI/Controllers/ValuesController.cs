﻿using AngularAPI.Models;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;

namespace WebAPI.Controllers
{
    [RoutePrefix("api/values")]
    public class ValuesController : ApiController
    {
        // GET api/values
        public IHttpActionResult Get()
        {
            using (TrainingDbContext training = new TrainingDbContext())
            {
                var fdafdsa = training.Trainings.ToList();
                return Ok(fdafdsa);
            }
        }

        [HttpGet]
        [Route("TrainingRecord")]
        public IHttpActionResult GetTrainingRecord()
        {
            List<Training> trainingslist = null;
            using (TrainingDbContext db = new TrainingDbContext())
            {
                trainingslist = db.Trainings.ToList();
            }

            return Ok(trainingslist);
        }

        [HttpPost]
        [Route("SaveTrainingRecord")]
        public IHttpActionResult SaveTrainingRecord([FromBody] Training training)
        {
            using (TrainingDbContext db = new TrainingDbContext())
            {
                db.Trainings.Add(training);
                db.SaveChanges();
            }
            return Ok(training);
        }

        // PUT api/values/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5
        public void Delete(int id)
        {
        }
    }
}
