﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace AngularAPI.Models
{
    public class TrainingDbContext:DbContext
    {
        public TrainingDbContext() : base("myConnectionString")
        {
            Database.SetInitializer<TrainingDbContext>(new CreateDatabaseIfNotExists<TrainingDbContext>());

        }
        public DbSet<Training> Trainings { get; set; }
    }
}