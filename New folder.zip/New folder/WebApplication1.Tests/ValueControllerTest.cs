﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using WebAPI.Controllers;

namespace WebApplication1.Tests
{
    [TestClass]
    public class ValueControllerTest
    {
        [TestMethod]
        public void TestMethod1()
        {
            ValuesController vc = new ValuesController();
        }
    }
}
