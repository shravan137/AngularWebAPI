import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { TrainingService } from './shared/training.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [TrainingService]
})
export class AppComponent implements OnInit {
  title = 'app';
  angularForm: FormGroup;
  submitted = false;
  trainingErrorMessage: string;
  startDateErrorMessage: string;
  endDateErrorMessage: string;

  constructor(private fb: FormBuilder, private trainingService: TrainingService, private toastrService: ToastrService) {
    this.angularForm = this.fb.group({
      trainingName: ['', [Validators.required]],
      startDate: ['', [Validators.required]],
      endDate: ['', [Validators.required]]
    });
    this.trainingErrorMessage = "Training Name is required";
    this.startDateErrorMessage = "Start Date is required";
    this.endDateErrorMessage = "End date is required";
  }

  ngOnInit() {

  }
  // convenience getter for easy access to form fields
  get f() { return this.angularForm.controls; }

  onSubmit() {
    this.submitted = true;
    if (this.angularForm.value.startDate > this.angularForm.value.endDate) {
      this.angularForm.controls['endDate'].setErrors({ 'endDateSmaller': true });
    } else {
      if (this.angularForm.value.endDate != "") {
        this.angularForm.controls['endDate'].setErrors(null);
      }

    }

    if (this.angularForm.valid) {
      this.trainingService.saveTrainingRecord(this.angularForm.value).subscribe((data: any) => {
        if (data.TrainingName) {
          // display form values on success
          var daysDiff = this.calculateDateDiff();
          this.toastrService.success('Training '+ data.TrainingName + 'saved successfully, Total number of days between dates start date and end date is ' + daysDiff + ' days', 'Success', { timeOut: 10000, positionClass: 'toast-top-center' });
          alert('Training "'+ data.TrainingName + '" saved successfully, Total number of days between dates start date and end date is ' + daysDiff + ' days');
          //alert("Save SUCCESS");
          this.angularForm.reset();
          this.angularForm.controls['startDate'].setErrors(null);
          this.angularForm.controls['endDate'].setErrors(null);
          this.angularForm.controls['trainingName'].setErrors(null);
        }
      });
    }
  }

  calculateDateDiff(): number {
    var date1 = new Date(this.angularForm.value.startDate);
    var date2 = new Date(this.angularForm.value.endDate);

    // To calculate the time difference of two dates 
    var timeDiff = date2.getTime() - date1.getTime();

    // To calculate the no. of days between two dates 
    var daysDiff = timeDiff / (1000 * 3600 * 24);
    return daysDiff;
  }

  getTrainingRecords() {
    if (this.angularForm.invalid) {
      this.trainingService.getTrainingRecord().subscribe((data: any) => {
        // display form values on success
        this.toastrService.success('Records fetched successfully', 'Success', { timeOut: 10000, positionClass: 'toast-top-center' });
        //alert("SUCCESS");
      });
    }
  }
}
