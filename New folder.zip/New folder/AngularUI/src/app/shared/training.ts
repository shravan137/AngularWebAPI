export class Training {
     trainingName: string;
     startDate: Date;
     endDate: Date
   }
   
   