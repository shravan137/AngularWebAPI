import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions, RequestMethod } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/map';

import { Training } from './training.model'

@Injectable()
export class TrainingService {

  selectedEmployee: Training;
  employeeList: Training[];
  constructor(private http: Http) { }

  saveTrainingRecord(training: Training) {
    var body = JSON.stringify(training);
    var headerOptions = new Headers({ 'Content-Type': 'application/json' });
    var requestOptions = new RequestOptions({ method: RequestMethod.Post, headers: headerOptions });
    return this.http.post('http://localhost:2220/api/values/SaveTrainingRecord', body, requestOptions).map(x => x.json()).catch((error: any) => {
      alert("exception while making api call");
      return Observable.of(error);
    });
  }

  getTrainingRecord() {
    return this.http.get('http://localhost:2220/api/values/TrainingRecord')
      .map((this.extractData)).catch((error: any) => {
        alert("exception while making api call");
        return Observable.of(error);
      })
  }

  private extractData(response: Response) {
    return response;
  }
}
